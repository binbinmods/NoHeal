# 1.2.1

Fixed a bug with Purple Only mode where it wouldn't be turned on properly

# 1.2.0

Updated for AtO version v1.6.0

# 1.1.1

Fixed a bug where enemies summoning pets could crash the game.

# 1.1.0

Added config option making only corrupted pets immortal.

# 1.0.0

Initial Release
